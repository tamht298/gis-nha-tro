var json_KhuNhaTroTDMpoint1={
"type": "FeatureCollection",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
                                                                                
"features": [
{ "type": "Feature", "properties": { "TENNHATRO": "Chu Nam", "TENCHUTRO": "Nguyen Van Nam", "SODIENTHOA": "0935656589", "DIACHI": "So 47, Tran Van On, Phu Hoa, Thu Dau Mot, Binh Duong" }, "geometry": { "type": "Point", "coordinates": [ 106.675176, 10.976317 ] } },
{ "type": "Feature", "properties": { "TENNHATRO": "Tran Hiep", "TENCHUTRO": "Tran Phuoc Hiep", "SODIENTHOA": "0932326662", "DIACHI": "So 82\/16 Nguyen Thi Minh Khai, P.Phu Hoa, Tp.Thu Dau Mot, tinh Binh Duong" }, "geometry": { "type": "Point", "coordinates": [ 106.688595, 10.979719 ] } },
{ "type": "Feature", "properties": { "TENNHATRO": "Tu Tam", "TENCHUTRO": "Le Trung Tam", "SODIENTHOA": "0955545455", "DIACHI": "So 189, Tran Van On, Phu Hoa, Thu Dau Mot, Binh Duong" }, "geometry": { "type": "Point", "coordinates": [ 106.673163, 10.977322 ] } },
{ "type": "Feature", "properties": { "TENNHATRO": "Ba Hieu", "TENCHUTRO": "Ba Van Hieu", "SODIENTHOA": "0955454455", "DIACHI": "385, Duong Le Hong Phong, Phuong Phu Hoa, Thanh pho Thu Dau Mot, Binh Duong" }, "geometry": { "type": "Point", "coordinates": [ 106.675783, 10.963047 ] } }
]
}
