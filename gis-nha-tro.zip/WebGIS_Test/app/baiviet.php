<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class baiviet extends Model
{
    //
    protected $table='baiviet';
    protected $primaryKey = 'id';
    public $timestamps = false;
    public $incrementing = false;
}
