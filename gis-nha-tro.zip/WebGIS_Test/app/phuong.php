<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class phuong extends Model
{
    //
    protected $table='vungranhgioiphuongtxtdm_region';
    protected $primaryKey = 'gid';
    public $timestamps = false;
    public $incrementing = false;
}
